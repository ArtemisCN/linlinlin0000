/*package dml.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/jsj")
public class Con1 {
    @RequestMapping("/aaa")
    public String add(){
        System.out.println("Hello");
        return "/jsp/first.jsp";
    }
}
*/