public class hello {

    public static void main(String[] args) {

        String[] a = new String[5];
        a[0]="123";
        a[1]="456";
        a[2]="789";
        a[3]="ABC";
        a[4]="DEF";


        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i]);


        }
one();
    }
    public static void one(){
        System.out.println("233");
    }
}
