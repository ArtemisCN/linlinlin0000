package lzq.demo.dao;

public class EmpService {
    private Emp emp;
    private double total;
    public EmpService() {
    }

    public EmpService(Emp emp, double total) {
        this.emp =  emp;
        this.total = total;
    }

    public Emp getEmp() {
        return emp;
    }

    public void setEmp(Emp emp) {
        this.emp = emp;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    public void sum()
    {
        total = emp.getGz()+emp.getJj();
    }
}
