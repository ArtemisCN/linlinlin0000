package lzq.demo.dao;

public interface IDao {
    void say();
}
