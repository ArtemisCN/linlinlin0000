package lzq.demo.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
       /* Emp emp =new Emp("张三丰",100,200,500);
        emp.say();
        EmpService es = new EmpService(emp,0);
        es.sum();
        System.out.println(es.getTotal());
        Emp emp1 =new Emp();*/

        ApplicationContext add =
                new
                ClassPathXmlApplicationContext("ApplicationContext.xml");


        Emp emp= (Emp)add.getBean("emp");
        emp.say();
        EmpService es =new EmpService(emp,0);
        es.sum();
        System.out.println(es.getTotal());
    }
}
