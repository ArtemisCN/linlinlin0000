package lzq.demo.dao;

public class Emp implements IDao{
    private String name;
    private int age;
    private double gz;
    private double jj;

    public Emp() {
    }

    public Emp(String name, int age, double gz, double jj) {
        this.name = name;
        this.age = age;
        this.gz = gz;
        this.jj = jj;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getGz() {
        return gz;
    }

    public void setGz(double gz) {
        this.gz = gz;
    }

    public double getJj() {
        return jj;
    }

    public void setJj(double jj) {
        this.jj = jj;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", gz=" + gz +
                ", jj=" + jj +
                '}';
    }

    @Override
    public void say() {

    }
}
